class Toolbox {
    constructor(){

    }

    display(){
        var box = createCanvas(400,1090);
        box.background("blue");


    }
}

